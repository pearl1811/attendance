<?php
class Attendance_Ajax_Action extends Vtiger_Action_Controller 
{
    public function checkPermission() 
    {
            return true;
    }
    public function process(Vtiger_Request $request) 
    {
        $date = $request->get('date');
        $data = Attendance_List_View::getUsersAttendaceDetails($date, true);
        $response = new Vtiger_Response();
        $response->setResult($data);
        return $response;
    }
}