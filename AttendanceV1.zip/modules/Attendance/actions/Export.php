<?php
class Attendance_Export_Action extends Vtiger_Action_Controller 
{
    public function checkPermission() 
    {
        return true;
    }
    public function process(Vtiger_Request $request) 
    {
        $output = '';

        $attendanceList = $statusDetail = $dateList = $attendance = array();
        $fromDate = date("Y-m-d", strtotime($request->get('fromDate')));
        $toDate = date("Y-m-d", strtotime($request->get('toDate')));

        $output .= "<table><tr><td>Filter Date</td><td>" . date("d-m-Y", strtotime($fromDate))."</td><td> To </td><td>".date("d-m-Y", strtotime($toDate))."</td></tr>";

        //Date display in head
        $output .= "<tr><th>Name</th>";
        $dateList = $this->createDateRange($fromDate, $toDate);
        foreach ($dateList as $key => $date) {
            $output .= "<th>".$key."</th>"; 
        }
        $output .= "</tr>";

        $export = [];

        //Get all user data
        $users = Users_Record_Model::getAll();

        foreach ($users as $key => $user) {

            $attendance = Attendance_Record_Model::findUserAttendance($fromDate, $toDate, $user->get('id'));
            $attendanceList = '';
            foreach ($attendance as $key => $atte) {
                $attendanceList[date("d-m-Y", strtotime($atte->get('attendance_date')))] = $atte->get('status');
            }
            $output .= "<tr><td>".$user->get('first_name')." ".$user->get('last_name')."</td>";

            $statusDetail = array_replace($dateList, $attendanceList);
            foreach ($statusDetail as $key => $value) {
                $output .= "<td>".$value."</td>";
            }
            $output .= "</tr>";
        }
        $output .= "</table>";
        //Excel convert
        header( "Content-Type: application/vnd.ms-excel" );
        header( "Content-disposition: attachment; filename=OrderReport".date("d-m-Y"). date("H:i").".xls" );
        echo $output;exit;

    }

    function createDateRange($start, $end)
    {
        $interval = new DateInterval('P1D');

        $realEnd = new DateTime($end);
        $realEnd->add($interval);

        $period = new DatePeriod(
             new DateTime($start),
             $interval,
             $realEnd
        );
        foreach($period as $date) { 
            $array[$date->format('d-m-Y')] = ''; 
        }
        return $array;
    }

    function getDatesFromRange($start, $end)
    {
        $dates = array($start);
        while(end($dates) < $end){
            $dates[] = date('Y-m-d', strtotime(end($dates).' +1 day'));
        }

        return $dates;
    }
}