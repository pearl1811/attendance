<?php
class Attendance_Save_Action extends Vtiger_Action_Controller 
{
    public function checkPermission() 
    {
        return true;
    }
    public function process(Vtiger_Request $request) 
    { 
        $data = $request->get('data');
        $time = $request->get('time');
        $insertData = [];
        $parsedDate = date_parse(date('Y-m',$time));

        foreach ($data as $user => $attendance) {
            foreach ($attendance as $key => $value) {
                $dateForm = sprintf('%d-%d-%d', $parsedDate['year'], $parsedDate['month'], $value);
                $atten = date_create($dateForm);
                $insertData[$user][$key]['user_id'] = $user;
                $insertData[$user][$key]['attendance_date'] = date_format($atten, 'Y-m-d H:i:s');
                $insertData[$user][$key]['status'] = $request->get('type');
                $insertData[$user][$key]['created_on'] = date('Y-m-d H:m:s');
                $insertData[$user][$key]['created_by'] = 1;
                $insertData[$user][$key]['modified_on'] = date('Y-m-d H:m:s');
                $insertData[$user][$key]['modified_by'] = 1;
            }
        }
        Attendance_Record_Model::create($insertData);
        $response = new Vtiger_Response();
        $response->setResult();
        return $response;
    }
}