<?php
class Attendance_Record_Model extends Vtiger_Base_Model 
{
    public function save() 
    {
        $db = PearDatabase::getInstance();
        $db->pquery('INSERT INTO vtiger_attendance (user_id, attendance_date, status, created_on, created_by, modified_on, modified_by) VALUES(?,?)', array(
            $this->get('url'), $this->get('title')
        ));

        return $db->getLastInsertID();
    }

    static function create($data) 
    {
        $db = PearDatabase::getInstance();
        foreach ($data as  $userList) {
            foreach ($userList as $value) {
                $db->pquery('INSERT INTO vtiger_attendance (user_id, attendance_date, status, created_on, created_by, modified_on, modified_by) VALUES(?,?,?,?,?,?,?)', array(
                    $value['user_id'], $value['attendance_date'], $value['status'], $value['created_on'], $value['created_by'], $value['modified_on'], $value['modified_by'])
                );
            }
        }

        return true;
    }

    static function findWithUrl($url) 
    {
        $db = PearDatabase::getInstance();
        $rs = $db->pquery('SELECT * FROM vtiger_attendance WHERE url=?', array($url));

        return $db->num_rows($rs)? new self($db->fetch_array($rs)) : NULL;
    }

    static function findAll() 
    {
        $db = PearDatabase::getInstance();
        $instances = array();
        $rs = $db->pquery('SELECT * FROM vtiger_attendance ORDER BY id DESC', array());
        if ($db->num_rows($rs)) {
                while ($data = $db->fetch_array($rs)) {
                        $instances[] = new self($data);
                }
        }

        return $instances;
    }

    static function findByUser($userId, $attendaceDateFrom, $attendaceDateTo)
    {
        $db = PearDatabase::getInstance();
        $instances = array();
        $rs = $db->pquery('SELECT * FROM vtiger_attendance where user_id=? and date(attendance_date) >= ? AND date(attendance_date) <= ? ORDER BY attendance_date DESC', array($userId, $attendaceDateFrom, $attendaceDateTo));
        if ($db->num_rows($rs)) {
                while ($data = $db->fetch_array($rs)) {
                        $instances[] = new self($data);
                }
        }

        return $instances;
    }

    static function findUserAttendance($attendaceDateFrom, $attendaceDateTo, $userId)
    {
        $db = PearDatabase::getInstance();
        $instances = array();
        $rs = $db->pquery('SELECT attendance_date, status FROM vtiger_attendance where user_id = ? AND date(attendance_date) >= ? AND date(attendance_date) <= ? ORDER BY user_id,attendance_date ASC', array($userId, $attendaceDateFrom, $attendaceDateTo));
        if ($db->num_rows($rs)) {
                while ($data = $db->fetch_array($rs)) {
                        $instances[] = new self($data);
                }
        }

        return $instances;
    }
}