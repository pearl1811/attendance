<?php
class Attendance_List_View extends Vtiger_Index_View 
{
    public $calenderDate;

    public $monthStartDate;

    public function preProcess(Vtiger_Request $request, $display = true) 
    {
        $feeds = Attendance_Record_Model::findAll();
        $viewer = $this->getViewer($request);
        $users = $this->getUsersAttendaceDetails(strtotime(date('Y-m-d')), false);
        $timeStamp = $this->generateTimeStamp();
        $viewer->assign('timeStamp', $timeStamp);
        $viewer->assign('users', $users);
        
        return parent::preProcess($request, $display);
    }

    public function getHeaderScripts(Vtiger_Request $request) 
    {
        $headerScriptInstances = parent::getHeaderScripts($request);
        $moduleName = $request->getModule();
        $jsFileNames = array(
                "modules.$moduleName.resources.jquery_rss_min",
        );
        $jsScriptInstances = $this->checkAndConvertJsScripts($jsFileNames);
        $headerScriptInstances = array_merge($headerScriptInstances, $jsScriptInstances);
        
        return $headerScriptInstances;
    }

    public function getCalenders()
    {
        $date = $this->calenderDate;
        date_default_timezone_set("Asia/Kolkata");
        $day = date('d', strtotime(date('Y-m-d')));
        $currentMonth = date('m', strtotime(date('Y-m-d')));
        $currentYear = date('Y', strtotime(date('Y-m-d')));
        $month = date('m', $date);
        $year = date('Y', $date);
        $firstDay = mktime(0,0,0,$month, 1, $year);
        $this->monthStartDate = date("Y-m-d",$firstDay);
        $title = strftime('%B', $firstDay);
        $daysInMonth = cal_days_in_month(0, $month, $year);
        $html = '<td>Employee Name</td>';
        for($i = 1; $i <= $daysInMonth; $i++):
            if($day == $i && $month == $currentMonth && $currentYear == $year):
                $html.="<td class='today'><strong>$i</strong></td>";
            else:
                $html.="<td>$i</td>";
            endif; 
        endfor;

        return ['html' => $html, 'daysInMonth' => $daysInMonth, 'month' => $month, 'todayDate' => $day, 'year' => $year, 'title' => $title, 'currentMonth' => $currentMonth, 'currentYear' => $currentYear];
    }

    public function getUsersAttendaceDetails($time, $isPast)
    {
        $users = Users_Record_Model::getAll();

        $this->calenderDate = $time;

        $calenderDetails = Attendance_List_View::getCalenders();

        $toDate = date('Y-m-d H:m:s',$time);

        if ($isPast) {
            $dateForm = sprintf('%d-%d-%d', $calenderDetails['year'], $calenderDetails['month'], $calenderDetails['daysInMonth']);
            $atten = date_create($dateForm);
            $toDate = date_format($atten, 'Y-m-d');
        }

        $usersList = '';
        $days = [];
        $total ='<tr class="total-row"><td></td>';
        for ($i = 1; $i <= $calenderDetails['daysInMonth']; $i++) {
            if (((($calenderDetails['currentMonth'] == $calenderDetails['month'] && $i > $calenderDetails['todayDate'] && $calenderDetails['year'] >= $calenderDetails['currentYear']) || ($calenderDetails['month'] > $calenderDetails['currentMonth'] && $calenderDetails['year'] >= $calenderDetails['currentYear']) || ($calenderDetails['year'] > $calenderDetails['currentYear'])))){
                $days[$i] = '<td></td>';
                $total.= '<td></td>';
            } else {
                $days[$i] = '<td><input type="checkbox" name="attendance[]" value="'.$i.'"/></td>';
                $total.= '<td><input type="checkbox" /></td>';
            }
        }

        foreach ($users as $key => $value) {
            $usersList.= "<tr class='usersList' user-id=".$value->get('id')."><td>".$value->get('first_name')." ".$value->get('last_name')."</td>";
            $userId = $value->get('id');
            $attendance = Attendance_Record_Model::findByUser($userId, $this->monthStartDate, $toDate);
            $userAttend = $days;
            foreach ($attendance as $atte) {
                $attendanceDate = date_parse($atte->get('attendance_date'));
                if (array_key_exists($attendanceDate['day'], $days)) {                    
                    $userAttend[$attendanceDate['day']] = "<td class=".$atte->get('status').">".Attendance_List_View::statusFreeText($atte->get('status'))."</td>";
                }
            }

            $usersList.= implode('',$userAttend).'</tr>';
        }

        $usersList.=$total;

        return ['usersList' => $usersList, 'dateGrid' => $calenderDetails ,'timeStamp' => Attendance_List_View::generateTimeStamp()];
    }

    public function generateTimeStamp()
    {
        $month = date('m', $this->calenderDate);
        $preMonth = strtotime("-1 month", $this->calenderDate);
        $nextMonth = strtotime("+1 month", $this->calenderDate);

        return ['preMonth' => $preMonth, 'nextMonth' => $nextMonth, 'currentTime' => $this->calenderDate];
    }

    public function statusFreeText($status)
    {
        switch ($status) {
            case 'absent':
                $code = "Ab";
                break;
            case 'present':
                $code = "P";
                break;
            case 'holiday':
                $code = "H";
                break;
            case 'leave':
                $code = "L";
            break;
            case 'halfday':
                $code = "H/D";
            break;
            
            default:
               $code = 'N/A';
                break;
        }

        return $code;
    }

}