jQuery.Class('Attendance_List_Js', {}, {

    registerEvents: function() {
        this.prevNextAction();
        this.selectTotal();
        this.formSubmitAction();
        this.datepicker();
    },

    prevNextAction: function() 
    {
        jQuery(document).on('click', '.paginate', function(){
            var time = $(this).attr('time');
            jQuery.ajax({
                url:'index.php?module=Attendance&action=Ajax&date='+time,
                dataType:'json',
                success:function(data)
                {
                    if (data.success == true) {
                        target = jQuery('.attendance-table');
                        target.find('thead tr').html(data.result.dateGrid.html);
                        target.find('tbody').html(data.result.usersList);
                        jQuery('.year-and-month').html(data.result.dateGrid.title+data.result.dateGrid.year);
                        jQuery('.paginate.prev').attr("time", data.result.timeStamp.preMonth);
                        jQuery('.paginate.next').attr("time", data.result.timeStamp.nextMonth);
                        jQuery('#currentTime').val(data.result.timeStamp.currentTime);
                    }
                },
                error:function(error)
                {
                    alert("Error:Please flush your browser cache and try again.");
                }
            })
        });
    },

    selectTotal: function() 
    {
        jQuery(document).on('click', '.attendance-table .total-row td', function(){
            var target = jQuery(this).index()+1;
            if(jQuery(this).find('input').is(':checked')){
                jQuery('.attendance-table').find('tbody td:nth-child('+target+') input').attr('checked', true)
            } else {
                jQuery('.attendance-table').find('tbody td:nth-child('+target+') input').attr('checked', false)
            }
        });
    },

    formSubmitAction: function()
    {
        jQuery('#entry-point').on('click', function(){

            var target = jQuery('.attendance-table').find('.usersList td input:checked');
            if (target.length > 0) {
                var attendance = new Object();
                var type = jQuery('#status').val();
                var time = jQuery('#currentTime').val();
                $.each(target, function(i, item){

                    var value =$(item).val()

                    var parent = $(item).parents('.usersList');
                      
                    var attendanceArr = [];

                    if (attendance[parent.attr('user-id')] == undefined){
                        attendance[parent.attr('user-id')] = [];
                    }

                    attendance[parent.attr('user-id')].push(value)
                });

                jQuery.ajax({
                    url:'index.php?module=Attendance&action=Save&type='+type+'&time='+time,
                    dataType:'json',
                    type:"POST",
                    data:{'data': attendance},
                    success:function(data)
                    {
                        location.reload(true);
                    },
                    error:function(error)
                    {
                        alert("Error:Please flush your browser cache and try again.");
                    }
                });
            } else {
                alert('Please select any of one data');
            }
        });
    },

    datepicker: function()
    {
        jQuery('.datepicker').datepicker({
             dateFormat: 'yyyy-mm-dd'
        });
    }

});